"""AST node definitions for Moxie."""


class N:
    __slots__ = ("line",)
    _fields = ()

    def __repr__(self):
        inner = ", ".join(f"{f}={getattr(self, f, None)!r}" for f in self._fields)
        return f"{type(self).__name__}({inner})"


def _make(name, fields):
    fields = tuple(fields.split()) if isinstance(fields, str) else tuple(fields)

    def __init__(self, *args, line=0, **kw):
        if len(args) > len(fields):
            raise TypeError(f"{name} takes {len(fields)} fields")
        for f, a in zip(fields, args):
            setattr(self, f, a)
        for f in fields[len(args):]:
            setattr(self, f, kw.pop(f, None))
        if kw:
            raise TypeError(f"{name}: unknown fields {list(kw)}")
        self.line = line
        if name == "Lambda":
            self.partial = False     # made by a call with `_` (takes the callee's effects)
            self.fiber = False       # the body of an inline `go fn (...)`
            self.free = False        # a step of an `eval impure` block: it may have effects

    extra = ("partial", "fiber", "free") if name == "Lambda" else ()
    cls = type(name, (N,), {"__slots__": fields + extra, "_fields": fields, "__init__": __init__})
    return cls


def _defs():
    g = globals()
    spec = {
        # literals
        "IntLit": "v suffix",
        "FloatLit": "v suffix",
        "DecLit": "text",
        "StrLit": "parts",          # parts: list of str | Interp
        "Interp": "expr spec src",
        "CharLit": "c",
        "BytesLit": "b",
        "ByteChar": "v",
        "KwLit": "name",
        "DurLit": "v unit",
        "BoolLit": "b",
        "UnitLit": "",
        # names
        "Name": "name",
        "PH": "idx",               # _ or _1 _2 ... placeholder
        "Slot": "",                # & in a pipe call
        "Gimme": "n name",
        "Carry": "items",          # first line of a block: `total, count@1, x@lap`: local copies of outer bindings; items: list of Gimme (n is None for the nearest)
        "Dollar": "expr",          # $name : variable used as a Dict key
        # compound
        "TupleE": "items",         # items: list of (label, expr, spread)
        "MArr": "rows",
        "Call": "fn args trailing chain",  # args: list of Arg
        "Arg": "label expr mod",   # mod: None 'ref' 'using' 'spread' 'move'
        "GenApp": "base groups",
        "Field": "obj name",
        "Unary": "op e",
        "Binary": "op l r",
        "AndE": "l r",
        "OrE": "l r",
        "InOp": "l r neg",
        "IsOp": "e pat",
        "RangeE": "lo hi incl step",
        "Pipe": "l stage",
        "Tick": "l fname r",
        "Q": "e",
        "IfE": "branches else_",       # branches: [(cond, body)]
        "WhenE": "scrut arms",         # arms: [Arm]
        "Arm": "pats guard body",
        "SeqE": "arms",                # [(pred, stage)]
        "SelectE": "arms",             # [SelArm]
        "SelArm": "kind bind expr body",   # kind: read closed cancelled default expr
        "ForE": "pat iter body else_ label",
        "WhileE": "cond body else_ label",
        "ForAll": "binds body",          # binds: list of (name, type)
        "DaemonE": "body",
        "WaitE": "name body",         # wait NAME: ... (NAME is the block's Cancel token, or None)
        "DoE": "body label",
        "WithE": "enums body",        # with A, B: ... (a block with the cases of enums A and B open; rewritten before checking)
        "DoRecv": "recv kind body",    # kind: do | update
        "UpdLine": "name expr nested",
        "UpdCur": "name",         # `&` in an `update` line: the current value of the field being updated
        "ForM": "lines yield_",        # lines: [(kind, pat, expr, else_)]
        "CompE": "kind elem key pat iter cond",
        "Block": "stmts",
        "Lambda": "params body recv locals ret",
        "Param": "pat name type default mod variadic where wtext",
        "RunE": "target limit try_",
        "TodoE": "msg",
        "PathE": "segs",
        "SqlE": "conn parts",
        "Ref": "e",                    # prefix ref
        "Move": "e",
        "Deref": "e",                  # @atom
        # statements
        "Assign": "targets value ann op vis lazy",
        "Refine": "name cond text alias",            # after `x Pos = v`: the alias's condition on `x` (made by the parser from `type alias Pos = Int where self > 0`)
        "ElseLet": "pat value else_ pat2",
        "Incr": "target delta",
        "Return": "e",
        "Break": "label e daemon",
        "Continue": "label",
        "TrailIf": "stmt cond",
        "ExprStmt": "e",
        # declarations
        "FnDecl": "name tparams params ret locals body flags clauses alias guard contracts",
        "FnGroup": "name clauses",
        "TupleDecl": "name tparams fields derivs positional vis invariants props",
        "FieldDecl": "name type default delegate prop",
        "PropertyDecl": "name type default cap get set did_set priv_set stored lazy static need will_set",
        "EnumDecl": "name tparams header cases derivs vis",
        "CaseDecl": "name fields ret tparams payload",
        "IfaceDecl": "name tparams members embeds vis",
        "ImplDecl": "iface target tparams members bodyless proxy",
        "AliasDecl": "kind name tparams type vis where wtext",
        "ImportDecl": "pkg alias names",
        "UsingDecl": "name expr",
        "InitDecl": "body",
        "TestDecl": "name body",
        "ForwardDecl": "fn",
        "ForeignDecl": "lib fns handles",
        "TParam": "name holes bounds where",
        # patterns
        "PWild": "",
        "PBind": "name",
        "PLit": "expr",
        "PRange": "lo hi incl step",
        "PTuple": "items",             # items: list of (label, pat)
        "PCon": "path args",           # args: list of (label, pat)
        "PAs": "name pat",
        "PPin": "expr",
        "PRel": "op operand",
        "PIn": "expr neg",            # `in 1..9 ->`, `in lo..hi step 2 ->`, `not in xs ->`: a membership test on any range or collection
        "PRest": "name",
        "PPlace": "expr",
        "PTyped": "pat type",
        "PBin": "elems",               # binary pattern: [("lit", [byte, ...]) | ("field", name|None, kind, arg)]
        # types
        "TName": "path groups",
        "TTuple": "items",
        "TFn": "params ret recv caps",
        "TUnion": "members",
        "TAny": "iface also",            # any Named + Aged: also lists the further interfaces (an intersection)
        "TStatic": "inner",
        "TBound": "name iface also",          # X: Show  in a type-function pattern: any type that implements Show, bound to X
        "TMatch": "scrut arms",          # when T: pattern -> type ...  (a type function; arms are (pattern, result) pairs)
        "TLambda": "params body",        # [A, M[_]] -> T: a type-level function (params are TParam)
        "TApp": "fn groups",             # ([A] -> T)[Int]: a lambda applied where it is written
        "THole": "",
        "TUnit": "",
        "TExpr": "expr",
    }
    for k, v in spec.items():
        g[k] = _make(k, v)


_defs()
