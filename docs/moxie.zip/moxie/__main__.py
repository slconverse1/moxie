"""moxie command line:  python -m moxie run|test|check FILE [args...]"""
import os
import sys

USAGE = """usage: moxie [--gc] [--release] [--pools] run FILE [args...]     run a program (--gc: moxie/gc rules; --release: contracts off)
       moxie [--allow-read[=PATHS]] [--allow-write[=PATHS]] [--allow-connect[=HOST:PORT]] [--allow-listen[=PORTS]]
             [--allow-ffi[=LIBS]] [--allow-stdin] [--allow-env] [--allow-all] [--deny-all] run FILE
                                    restrict what the program may touch (default: a [permissions] table in Moxie.toml, else everything)
       moxie test FILE [name]       run the test blocks (the entry body does not run)
       moxie check FILE             parse and check without running
       moxie pools FILE             the static pool tally: how many of each counted resource the program creates
       moxie bindgen HEADER (-o FILE | --package NAME) [--lib LIB] [--check]
                                    write foreign declarations from a C header
       moxie doc FILE [-o DIR] [--format md|html] [--private] [--check]
                                    generate documentation from /// comments; checks examples
       moxie -e 'code'              run a snippet
"""


def make_interp(path, args, perms=None):
    from .interp import Interp
    from .values import ArrayV, DictV
    I = Interp(search_dir=os.path.dirname(os.path.abspath(path)) if path else ".")
    I.prelude.vars["args"] = ArrayV(list(args))
    if perms is not None:
        I.perms = perms
    env = {k: v for k, v in os.environ.items()} if I.perms.env_ok() else {}
    I.prelude.vars["env"] = DictV(env, len(env))
    return I


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--gc" in argv:
        from .values import GC
        GC[0] = True
        argv = [a for a in argv if a != "--gc"]
    if "--release" in argv:
        from .values import CONTRACTS
        CONTRACTS[0] = False
        argv = [a for a in argv if a != "--release"]
    want_pools = "--pools" in argv
    argv = [a for a in argv if a != "--pools"]
    # permission flags come before the file name; after it they belong to the program
    pflags, rest, seen_file = [], [], False
    for a in argv:
        if not seen_file and (a.split("=")[0] in ("--allow-read", "--allow-write", "--allow-connect", "--allow-listen",
                                                  "--allow-ffi", "--allow-stdin", "--allow-env", "--allow-all", "--deny-all")):
            pflags.append(a)
            continue
        if not seen_file and not a.startswith("-") and a not in ("run", "test", "check", "bindgen", "doc"):
            seen_file = True
        rest.append(a)
    argv = rest
    sys.setrecursionlimit(100000)
    if not argv or argv[0] in ("-h", "--help", "help"):
        sys.stdout.write(USAGE)
        return 0 if argv else 2
    if argv[0] == "-e":
        I = make_interp(None, [])
        return I.run_source(argv[1], "<-e>")
    cmd = argv[0]
    if cmd == "bindgen":
        from .bindgen import main as bg_main
        return bg_main(argv[1:])
    if cmd == "doc":
        from .doc import doc_main
        return doc_main(argv[1:], lambda: make_interp(argv[1] if len(argv) > 1 else None, []),
                        sys.stdout, sys.stderr)
    if cmd == "pools":
        if len(argv) < 2:
            sys.stderr.write(USAGE)
            return 2
        from .lexer import MoxieSyntaxError
        try:
            src = open(argv[1], encoding="utf-8").read()
        except OSError as e:
            sys.stderr.write(f"moxie: cannot read {argv[1]}: {e.strerror}\n")
            return 2
        I = make_interp(argv[1], [])
        try:
            prog = I.load_source(src, os.path.basename(argv[1]))
        except MoxieSyntaxError as e:
            sys.stderr.write(str(e) + "\n")
            return 2
        from .tally import Tally, format_tally
        t = Tally(prog)
        sys.stdout.write(format_tally(t.program()))
        for line, msg in t.problems:
            sys.stdout.write(f"{os.path.basename(argv[1])}:{line}: error: {msg}\n")
        return 1 if t.problems else 0
    if cmd not in ("run", "test", "check"):
        cmd, argv = "run", ["run"] + argv
    if len(argv) < 2:
        sys.stderr.write(USAGE)
        return 2
    path = argv[1]
    try:
        src = open(path, encoding="utf-8").read()
    except OSError as e:
        sys.stderr.write(f"moxie: cannot read {path}: {e.strerror}\n")
        return 2
    from .perms import load_for, PermError
    try:
        perms = load_for(path, pflags)
    except PermError as e:
        sys.stderr.write(f"moxie: {e}\n")
        return 2
    if cmd == "run":
        I = make_interp(path, [a for a in argv[2:] if a != "--no-check"], perms)
        code = I.run_source(src, os.path.basename(path), check="--no-check" not in sys.argv)
        if want_pools:
            sys.stderr.write(I.pools.report())
            if getattr(I, "main_prog", None) is not None:
                from .tally import static_tally, format_tally, compare
                cnt = static_tally(I.main_prog)
                sys.stderr.write(format_tally(cnt))
                for w in compare(cnt, I.pools):
                    sys.stderr.write(w + "\n")
        return code
    if cmd == "test":
        I = make_interp(path, [], perms)
        p_, f_, code = I.run_tests(src, os.path.basename(path), argv[2] if len(argv) > 2 else None)
        if "/// >" in src and len(argv) <= 2:
            from .doc import collect, run_doctests
            clean, _, items = collect(src)
            for it, e, x, ok, msg in run_doctests(src, items, lambda: make_interp(path, [])):
                print(("ok    " if ok else "FAIL  ") + f"doctest {it.name}: {e}" + ("" if ok else f" ({msg})"))
                code = code or (0 if ok else 1)
        return code
    if cmd == "check":
        I = make_interp(path, [], perms)
        return I.check_source(src, os.path.basename(path))
    return 2


if __name__ == "__main__":
    try:
        code = main()
        sys.stdout.flush()
    except BrokenPipeError:
        code = 0
    sys.exit(code)
