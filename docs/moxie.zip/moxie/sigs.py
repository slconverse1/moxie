"""Signatures of prelude functions for the checker (check.py), written as moxie declarations in the order the arguments really
go (a stage takes its function first and its source last: `map(f, xs)`).  A name may have several: the checker uses an overload
only when exactly one fits the argument types it knows, so a call with an unknown argument is left unknown.  `Seq[T]` stands for
any source of T values: a List, an Array, a Set, a Ring, or a Stream.  The bodies are placeholders; only the headers are read.
"""

SRC = '''
fn map[T, U](f: (T) -> U, xs: Seq[T]) Stream[U]: 0
fn map[T, U, E](f: (T) -> U, r: Result[T, E]) Result[U, E]: 0
fn filter[T](f: (T) -> Bool, xs: Seq[T]) Stream[T]: 0
fn take[T](n: Int, xs: Seq[T]) Stream[T]: 0
fn drop[T](n: Int, xs: Seq[T]) Stream[T]: 0
fn take_while[T](f: (T) -> Bool, xs: Seq[T]) Stream[T]: 0
fn drop_while[T](f: (T) -> Bool, xs: Seq[T]) Stream[T]: 0
fn enumerate[T](xs: Seq[T]) Stream[(Int, T)]: 0
fn zip[A, B](a: Seq[A], b: Seq[B]) Stream[(A, B)]: 0
fn sort[T](xs: Seq[T]) Stream[T]: 0
fn sort_by[T, K](f: (T) -> K, xs: Seq[T]) Stream[T]: 0
fn reverse[T](xs: Seq[T]) Stream[T]: 0
fn reduce[T, A](init: A, f: (A, T) -> A, xs: Seq[T]) A: 0
fn collect[T](xs: Seq[T]) List[T]: 0
fn sum[T](xs: Seq[T]) T: 0
fn product[T](xs: Seq[T]) T: 0
fn count[T](xs: Seq[T]) Int: 0
fn any[T](f: (T) -> Bool, xs: Seq[T]) Bool: 0
fn all[T](f: (T) -> Bool, xs: Seq[T]) Bool: 0
fn find[T, E](f: (T) -> Bool, xs: Seq[T]) Result[T, E]: 0
fn first[T, E](xs: Seq[T]) Result[T, E]: 0
fn last[T, E](xs: Seq[T]) Result[T, E]: 0
fn partition[T](f: (T) -> Bool, xs: Seq[T]) (List[T], List[T]): 0
fn unzip[A, B](xs: Seq[(A, B)]) (List[A], List[B]): 0
fn upper(s: String) String: 0
fn upper(c: Char) Char: 0
fn lower(s: String) String: 0
fn lower(c: Char) Char: 0
fn abs(n: Int) Int: 0
fn abs(x: Double) Double: 0
fn min[T](a: T, b: T) T: 0
fn max[T](a: T, b: T) T: 0
fn clamp[T](x: T, lo: T, hi: T) T: 0
fn pow(a: Int, b: Int) Int: 0
fn pow(a: Double, b: Double) Double: 0
fn floor(x: Double) Int: 0
fn ceil(x: Double) Int: 0
fn round(x: Double) Int: 0
fn finite[E](x: Double) Result[Double, E]: 0
fn checked_add[T, E](a: T, b: T) Result[T, E]: 0
fn checked_sub[T, E](a: T, b: T) Result[T, E]: 0
fn checked_mul[T, E](a: T, b: T) Result[T, E]: 0
fn checked_div[T, E](a: T, b: T) Result[T, E]: 0
fn wrapping_add[T](a: T, b: T) T: 0
fn wrapping_sub[T](a: T, b: T) T: 0
fn wrapping_mul[T](a: T, b: T) T: 0
fn saturating_add[T](a: T, b: T) T: 0
fn saturating_sub[T](a: T, b: T) T: 0
fn saturating_mul[T](a: T, b: T) T: 0
fn parse_number[N, E](s: String) Result[N, E]: 0
fn chars(s: String) Stream[Char]: 0
fn graphemes(s: String) Stream[String]: 0
fn pad_left(s: String, n: Int) String: 0
fn pad_left(s: String, n: Int, c: String) String: 0
fn pad_left(s: String, n: Int, c: Char) String: 0
fn pad_right(s: String, n: Int) String: 0
fn pad_right(s: String, n: Int, c: String) String: 0
fn pad_right(s: String, n: Int, c: Char) String: 0
fn split(s: String, sep: String) List[String]: 0
fn join[T](xs: Seq[T], sep: String) String: 0
fn join[T](xs: Seq[T]) String: 0
fn replace_text(s: String, from: String, to: String) String: 0
fn repeat[T](x: T) Stream[T]: 0
fn keys[K, V](d: Dict[K, V]) Stream[K]: 0
fn values[K, V](d: Dict[K, V]) Stream[V]: 0
fn items[K, V](d: Dict[K, V]) Stream[(K, V)]: 0
fn get[K, V, E](d: Dict[K, V], k: K) Result[V, E]: 0
fn get[T, E](xs: List[T], i: Int) Result[T, E]: 0
fn get[T, E](xs: Array[T], i: Int) Result[T, E]: 0
fn get_or[T, E](r: Result[T, E], d: T) T: 0
fn get_or[K, V](d: Dict[K, V], k: K, d2: V) V: 0
fn get_or[T](xs: List[T], i: Int, d: T) T: 0
fn distinct[T](xs: Seq[T]) Stream[T]: 0
fn flatten[T](xs: Seq[Seq[T]]) Stream[T]: 0
fn cycle[T](xs: Seq[T]) Stream[T]: 0
fn intersperse[T](sep: T, xs: Seq[T]) Stream[T]: 0
fn zip_with[A, B, C](f: (A, B) -> C, xs: Seq[A], ys: Seq[B]) Stream[C]: 0
fn identity[T](x: T) T: 0
fn min_by[T, K, E](f: (T) -> K, xs: Seq[T]) Result[T, E]: 0
fn max_by[T, K, E](f: (T) -> K, xs: Seq[T]) Result[T, E]: 0
fn span[T](f: (T) -> Bool, xs: Seq[T]) (List[T], List[T]): 0
fn split_at[T](n: Int, xs: Seq[T]) (List[T], List[T]): 0
fn chunks[T](n: Int, xs: Seq[T]) Stream[List[T]]: 0
fn windows[T](n: Int, xs: Seq[T]) Stream[Array[T]]: 0
fn group_by[T, K](f: (T) -> K, xs: Seq[T]) Dict[K, List[T]]: 0
fn reduce_right[T, A](init: A, f: (T, A) -> A, xs: Seq[T]) A: 0
fn scan[T, A](init: A, f: (A, T) -> A, xs: Seq[T]) Stream[A]: 0
fn take_last[T](n: Int, xs: Seq[T]) Stream[T]: 0
fn to_stream[T](xs: Seq[T]) Stream[T]: 0
fn swap[T](a: Atom[T], f: (T) -> T) T: 0
fn reset[T](a: Atom[T], v: T) T: 0
fn map_err[T, E, F](r: Result[T, E], f: (E) -> F) Result[T, F]: 0
fn map_ok[T, U, E](r: Result[T, E], f: (T) -> U) Result[U, E]: 0
fn or_else[T, E, F](r: Result[T, E], f: (E) -> Result[T, F]) Result[T, F]: 0
fn unwrap[T, E](r: Result[T, E]) T: 0
fn ensure[E](ok: Bool, e: E) Result[Unit, E]: 0
fn path_ext(p: String) String: 0
fn path_name(p: String) String: 0
fn path_parent(p: String) String: 0
fn path_stem(p: String) String: 0
fn read_file[E](p: String) Result[String, E]: 0
fn write_file[E](p: String, s: String) Result[Unit, E]: 0
fn make_dir[E](p: String) Result[Unit, E]: 0
fn remove_file[E](p: String) Result[Unit, E]: 0
fn random_int(lo: Int, hi: Int) Int: 0
fn days_in_month(y: Int, m: Int) Int: 0
fn assert(ok: Bool) Unit: 0
fn assert_eq[T](a: T, b: T) Unit: 0
fn println() Unit: 0
fn println[T](x: T) Unit: 0
fn print[T](x: T) Unit: 0
fn eprintln() Unit: 0
fn eprintln[T](x: T) Unit: 0
fn eprint[T](x: T) Unit: 0
fn dbg[T](x: T) T: 0
fn trace[T](x: T) Unit: 0
fn random() Double: 0
fn random_bytes(n: Int) Array[Byte]: 0
fn sleep(d: Duration) Unit: 0
fn millis(d: Duration) Int: 0
fn nanos(d: Duration) Int: 0
fn seconds(d: Duration) Double: 0
fn weekday(t: DateTime) Int: 0
fn day_of_year(t: DateTime) Int: 0
fn iso(t: DateTime) String: 0
fn format_time(t: DateTime, fmt: String) String: 0
fn format_time(t: DateTime, fmt: String, loc: Locale) String: 0
fn iterate[T](seed: T, f: (T) -> T) Stream[T]: 0
fn contains(s: String, t: String) Bool: 0
fn contains[T](xs: Seq[T], x: T) Bool: 0
fn contains[K, V](d: Dict[K, V], k: K) Bool: 0
fn secret_eq[T](a: T, b: T) Bool: 0
fn close[T](x: T) Unit: 0
fn trim(s: String) String: 0
fn starts_with(s: String, prefix: String) Bool: 0
fn starts_with(s: String, c: Char) Bool: 0
fn ends_with(s: String, suffix: String) Bool: 0
fn ends_with(s: String, c: Char) Bool: 0
fn char_count(s: String) Int: 0
fn grapheme_count(s: String) Int: 0
fn path_join(base: String, rest: String) String: 0
fn is_ok[T, E](r: Result[T, E]) Bool: 0
fn is_err[T, E](r: Result[T, E]) Bool: 0
fn is_nan(x: Double) Bool: 0
fn is_inf(x: Double) Bool: 0
fn is_finite(x: Double) Bool: 0
fn sqrt(x: Double) Double: 0
fn cwd() String: 0
fn hostname() String: 0
fn os_name() String: 0
fn temp_dir() String: 0
fn home_dir[E]() Result[String, E]: 0
fn list_dir[E](p: String) Result[Array[String], E]: 0
fn path_exists[E](p: String) Result[Bool, E]: 0
fn remove_dir[E](p: String) Result[Unit, E]: 0
fn rename_path[E](a: String, b: String) Result[Unit, E]: 0
fn now() Duration: 0
fn monotonic() Duration: 0
fn remove[K, V](d: Dict[K, V], k: K) Dict[K, V]: 0
fn remove[T](s: Set[T], x: T) Set[T]: 0
fn remove[T](xs: List[T], x: T) List[T]: 0
fn remove[T](xs: Array[T], x: T) Array[T]: 0
fn clear[K, V](d: Dict[K, V]) Dict[K, V]: 0
fn clear[T](s: Set[T]) Set[T]: 0
fn clear[T](xs: List[T]) List[T]: 0
'''


# The two dialects differ here: in moxie a full collection refuses (`put` gives a Result), in moxie/gc `put` gives the collection.
SRC_MOXIE = '''
fn put[K, V, E](d: Dict[K, V], k: K, v: V) Result[Dict[K, V], E]: 0
fn put[T, E](xs: List[T], x: T) Result[List[T], E]: 0
fn put[T, E](s: Set[T], x: T) Result[Set[T], E]: 0
'''

SRC_GC = '''
fn put[K, V](d: Dict[K, V], k: K, v: V) Dict[K, V]: 0
fn put[T](xs: List[T], x: T) List[T]: 0
fn put[T](s: Set[T], x: T) Set[T]: 0
'''
